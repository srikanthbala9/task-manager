
import './App.css';
import Button from '@material-ui/core/Button';
import LinearProgress from '@material-ui/core/LinearProgress';
import TextField from '@material-ui/core/TextField';

function App() {
  return (
    <div className="App">
      
      <Button variant="contained" color="primary">
        Add Server
      </Button>
      <Button variant="contained" color="primary">
        Remove Server
      </Button>
      <LinearProgress value={80} />
      <TextField id="standard-basic" type="number" label="select no of tasks" />
      <Button variant="contained" color="primary" href="#contained-buttons">
        Add Task
      </Button>
    </div>
  );
}

export default App;
