import { decorate, observable, action, computed, toJS, reaction } from "mobx";

class Store {
    //variable in the store
    tasks = []
    noOfTasksToAdd = 0
    servers = [{ id: Math.random() }]
    removeServersCount = 0

    //function to adding  task to the task manager

    handleAddTask = () => {
        const newTasks = [];
        for (let i = 0; i < this.noOfTasksToAdd; i++) {
            newTasks.push({ id: Math.random(), progress: 0 });
        }

        this.tasks.push(...newTasks);
        this.handlePendingTasks();
    };

    //function to handle the pending tasks

    handlePendingTasks = () => {
       // console.log("HandlePendingTasks")
        //console.log(this.tasks.length)

        this.servers.forEach(server => {
            if (!server.isBusy) {
                server.isBusy = true;
                server.currentTask = this.tasks[0];
               // console.log(this.tasks.length)
                this.tasks = this.tasks.slice(1);
                //console.log(this.tasks.length)
                this.startTask(server.currentTask, server);
            }

            return server;
        });
     //   console.log(this.tasks.length)
    }
    //function to add servers to the tasks
    handleAddServer = () => {
        if (this.tasks.length == 0) {
            window.alert("No pending tasks");
            return;
        }
        if (this.servers.length >= 10) {
            window.alert("Max servers reached");
            return;
        }
        this.servers.push({ id: Math.random(), isBusy: false });
        this.handlePendingTasks();
    };

    //function to remove allocated servers
    handleRemoveServer = () => {
        if (this.servers.length - this.removeServersCount <= 1) {
            return;
        }
        this.removeServersCount += 1;
    }

    //setting number of tasks
    setNoOfTasks = (value) => {
        this.noOfTasksToAdd = value
    }

//on completion of task remove the task form the list
    handleTaskComplete = (taskId, server) => {
        server.isBusy = false;
        server.currentTask = {};
        // if (this.tasks.length === 0) {
        this.removeServers()
        // } else {
        setTimeout(() => this.handlePendingTasks(), 100);
        // }
    }

    //removed the servers allocated to the tasks
    removeServers = () => {
        const newServers = this.servers.filter(server => {
            if (!server.isBusy && this.tasks.length > 0 && this.removeServersCount > 0) {
                this.removeServersCount -= 1;
                return true;
            }
            return server.isBusy
        });
        this.servers = newServers.length == 0 ? [{ id: Math.random() }] : newServers;
    }

    //funtion to set the tasks progress bar and remove after 20 seconds
    startTask = (task, server) => {
        const timerId = setInterval(() => {
            if (typeof task == undefined) {
                clearInterval(timerId);
                return;
            }
            task.progress += 5;

            if (task.progress >= 100) {
                clearInterval(timerId);
                this.handleTaskComplete(task.id, server);
            }
        }, 1000);
    }

    deleteTask = (index) => {
        this.tasks.splice(index, 1);
    }

}

decorate(Store, {
    tasks: observable,
    noOfTasksToAdd: observable,
    servers: observable,
    removeServersCount: observable,
})
const store = new Store()
export default store;
reaction(
    () => store.tasks,
    function (value, previousValue, reaction) {
        console.log(arguments);
    }
);