import logo from './logo.svg';
import './App.css';
import React from "react";
import { Button, LinearProgress, TextField, IconButton } from '@material-ui/core';
import DeleteIcon from "@material-ui/icons/Delete"
import store from "./Store";
import { observer } from 'mobx-react';
window.store = store;
function App() {
 

  return (
    <div className="App">
      <Button variant="contained" color="primary" onClick={store.handleAddServer}>Add Server</Button>
      <Button variant="contained" color="primary" onClick={store.handleRemoveServer}>Remove Server</Button>

      <div>
        <TextField type="number" 
        value={store.noOfTasksToAdd}
        InputProps={{
          inputProps: { 
              max: 10, min: 0 
          }
      }}
        onChange={(e) => store.setNoOfTasks(e.target.value)} /> <Button onClick={store.handleAddTask}>Add Task</Button>
      </div>
      <div>
        {/* Pending Tasks: */}
        {/* {store.tasks.length} */}
        {/* {JSON.stringify(store.tasks)} */}
      </div>
      {/* {store.removeServersCount} */}
      {store.servers.map((server, i) => {
        const task = server.currentTask;
        return <div key={server.id} style={{ width: 500 }}>
          {/* <div>
            {server.isBusy ? "Busy" : "Available"}
          </div> */}
          {/* {JSON.stringify(task)} */}
          {server.isBusy && task?.id != undefined &&
            < TaskObserver onComplete={store.handleTaskComplete} server={server} onDelete={() => { }} key={task.id} id={task.id} task={task} deleteHidden />
          }
        </div>
      })}
      {store.tasks.map((task, i) => <div key={task.id} style={{ width: 500 }}><TaskObserver onDelete={() => store.deleteTask(i)} key={task.id} task={task} /></div>)}
    </div>
  );
}
const TaskObserver = observer(Task)
function Task({ onComplete, onDelete, id, task, server, deleteHidden }) {
 
  return (
    <div>
      {/* {task.id} */}
      <LinearProgress variant="buffer" value={(task.progress)} valueBuffer={5} />
      {(task.progress/5)} seconds
      {!deleteHidden && <IconButton>
        <DeleteIcon onClick={onDelete} />
      </IconButton>}
    </div>
  );
}
export default observer(App);
